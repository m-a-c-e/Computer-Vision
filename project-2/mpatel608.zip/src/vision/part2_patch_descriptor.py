#!/usr/bin/python3

import numpy as np


def compute_normalized_patch_descriptors(
    image_bw: np.ndarray, X: np.ndarray, Y: np.ndarray, feature_width: int
) -> np.ndarray:
    """Create local features using normalized patches.

    Normalize image intensities in a local window centered at keypoint to a
    feature vector with unit norm. This local feature is simple to code and
    works OK.

    Choose the top-left option of the 4 possible choices for center of a square
    window.

    Args:
        image_bw: array of shape (M,N) representing grayscale image
        X: array of shape (K,) representing x-coordinate of keypoints
        Y: array of shape (K,) representing y-coordinate of keypoints
        feature_width: size of the square window

    Returns:
        fvs: array of shape (K,D) representing feature descriptors
    """

    ###########################################################################
    # TODO: YOUR CODE HERE                                                    #
    ###########################################################################
    fvs = []
    shift = 0
    if feature_width % 2 == 0:
        # it is a square of even side
        shift = feature_width // 2 - 1
        for (x, y) in zip(X, Y):
            img_slice = image_bw[x - shift : x + shift + 1 + 1, y - shift : y + shift + 1 + 1].flatten()
            img_slice = img_slice / np.linalg.norm(img_slice)
            fvs.append(img_slice)
    else:
        shift = (feature_width - 1) // 2
        for (x, y) in zip(X, Y):
            img_slice = image_bw[x - shift : x + shift, y - shift : y + shift]
            img_slice = img_slice / np.linalg.norm(img_slice)
            fvs.append(img_slice)
    
    fvs = np.array(fvs, dtype=np.float32)
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################

    return fvs
