import numpy as np

bins = np.array([-1, -3/4, -1/2, -1/4, 0, 1/4, 1/2, 3/4, 1]) * np.pi
print(np.round(bins, 5))

